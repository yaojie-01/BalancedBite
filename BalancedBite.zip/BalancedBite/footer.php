<link rel="stylesheet" type="text/css" href="<?php echo 'style_footer.css'; ?>">
<div class="footer">
    <div class="rights">
        <p>
            © 2025 BalancedBite. All Rights Reserved.
        </p>
    </div>
    <div class="line"></div>
    <div class="contacts">
        <p>
            <strong>Contacts</strong><br>
            Email: BalancedBite@gmail.com <br>
            Phone: 123-456-7890
        </p>
    </div>
</div>
