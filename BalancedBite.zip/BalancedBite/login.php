The PHP code you provided is for processing the login form data, checking credentials, and setting session variables. It should be placed before any HTML output in your login.php file.

Here's how to structure your login.php file correctly:

PHP

<?php
session_start();
require 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id, $db_username, $db_password);
            $stmt->fetch();

            if ($password === $db_password) {
                $_SESSION['user_id'] = $user_id;
                $_SESSION['username'] = $db_username;

                header("Location: index.php");
                exit();
            } else {
                $error = "Invalid username or password.";
            }
        } else {
            $error = "User not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="icon" href="BALANCE_BITE.webp" type="image/x-icon">
    <link rel="stylesheet" href="style_in_up.css">
</head>
<body>

    <div class="overlay">
        <video autoplay loop muted playsinline class="overlay-video">
        <source src="food.mp4" type="video/mp4">
        </video>
        <div class="sign_in_box">
            <h2>Sign In</h2>

            <?php if (isset($error)): ?>
                <p style="color: red;"><?php echo $error; ?></p>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <label for="username" class="username_label">Username</label>
                <input type="text" name="username" required placeholder="Enter your username">

                <label for="password" class="password_label">Password</label>
                <input type="password" name="password" required placeholder="Enter your password">

                <a href="register.php" class="change_btn"> Don't have an account? Sign Up</a>

                <div class="all_btn">
                    <a href="index.php" class="back_btn">Back</a>
                    <button type="submit" class="sign_in_btn">Sign In</button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>