<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    echo "<p>You need to <a href='login.php'>log in</a> to view your results.</p>";
    exit;
}

$user_id = $_SESSION['user_id'];

$query = "SELECT quiz_id FROM quiz_results WHERE user_id = ? ORDER BY quiz_id DESC LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($latest_quiz_id);
$stmt->fetch();
$stmt->close();

if (!$latest_quiz_id) {
    echo "<p>No results found.</p>";
    exit;
}

$query = "SELECT deficiency, severity FROM quiz_results WHERE user_id = ? AND quiz_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $user_id, $latest_quiz_id);
$stmt->execute();
$result = $stmt->get_result();

$deficiencies = [];
while ($row = $result->fetch_assoc()) {
    $deficiencies[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="BALANCE_BITE.webp" type="image/x-icon">
    <title>Your Results</title>
    <link rel="stylesheet" type="text/css" href="style_result.css">
</head>
<body>

<?php include 'header.php'; ?>

<?php include 'result_box.php'; ?>



<?php include 'footer.php'; ?>

</body>
</html>