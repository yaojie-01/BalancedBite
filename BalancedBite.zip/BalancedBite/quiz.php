<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require 'db_connection.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['current_question'])) {
    $query = "SELECT MIN(id) AS first_id FROM questions";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row) {
        $_SESSION['current_question'] = $row['first_id'];
        $_SESSION['answers'] = [];
        $_SESSION['quiz_started'] = true;
        $_SESSION['total_questions'] = $conn->query("SELECT COUNT(*) FROM questions")->fetch_row()[0];
    } else {
        die("Error: No questions found.");
    }
}

$current_id = $_SESSION['current_question'];

if (isset($_GET['back']) && !empty($_SESSION['answers'])) {
    end($_SESSION['answers']); 
    $prev_question_id = key($_SESSION['answers']);
    unset($_SESSION['answers'][$prev_question_id]); 
    $_SESSION['current_question'] = $prev_question_id;
    header("Location: quiz.php");
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['answer'], $_POST['question_id'])) {
    $question_id = (int) $_POST['question_id'];
    $answer = (int) $_POST['answer'];

    $_SESSION['answers'][$question_id] = $answer;


    $query = "SELECT id FROM questions WHERE id > ? ORDER BY id ASC LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $question_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row) {
        $_SESSION['current_question'] = $row['id'];
    } else {
        $_SESSION['current_question'] = null;
        header("Location: submit_quiz.php");
        exit();
    }

    header("Location: quiz.php");
    exit();
}


if ($current_id) {
    $sql = "SELECT * FROM questions WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $current_id);
    $stmt->execute();
    $result = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="BALANCE_BITE.webp" type="image/x-icon">
    <title>Quiz</title>
    <link rel="stylesheet" href="styles_quiz.css">
</head>
<body>
    <main class="quiz-container">
        <?php if ($current_id && $result->num_rows > 0) :
            $row = $result->fetch_assoc();
        ?>
            <h2 class="quiz-title">Nutrition Deficiency Quiz</h2>
            <p class="quiz-question"><?php echo htmlspecialchars($row['question_text']); ?></p>

            <form action="quiz.php" method="post" class="quiz-form">
                <input type="hidden" name="question_id" value="<?php echo $row['id']; ?>">

                <div class="quiz-options">
                    <label class="quiz-option">
                        <input type="radio" name="answer" value="0" required> Never
                    </label>
                    <label class="quiz-option">
                        <input type="radio" name="answer" value="1"> Rarely
                    </label>
                    <label class="quiz-option">
                        <input type="radio" name="answer" value="2"> Sometimes
                    </label>
                    <label class="quiz-option">
                        <input type="radio" name="answer" value="3"> Often
                    </label>
                    <label class="quiz-option">
                        <input type="radio" name="answer" value="4"> Always
                    </label>
                </div>

                <div class="quiz-buttons">
                    <a href="quiz.php?back=1" class="quiz-button back-button <?php echo empty($_SESSION['answers']) ? 'disabled' : ''; ?>">Back</a>
                    <button type="submit" class="quiz-button">Next</button>
                </div>

                <audio id="clickSound">
                    <source src="ding.mp3" type="audio/mpeg">
                </audio>

            </form>

        <?php endif; ?>
    </main>

    <script>
        document.querySelectorAll(".quiz-option input").forEach(input => {
            input.addEventListener("change", function () {
                document.querySelectorAll(".quiz-option").forEach(label => label.classList.remove("selected"));
                this.parentElement.classList.add("selected");
            });
        });

        document.addEventListener('DOMContentLoaded', function() {
            const backButton = document.querySelector('.back-button');
            const nextButton = document.querySelector('.quiz-button[type="submit"]');
            const clickSound = document.getElementById('clickSound');

            if (backButton) {
                backButton.addEventListener('click', function() {
                    clickSound.currentTime = 0;
                    clickSound.play();
                });
            }

            if (nextButton) {
                nextButton.addEventListener('click', function(event) {
                    event.preventDefault(); 
                    clickSound.currentTime = 0;
                    clickSound.play();

                    setTimeout(function() {
                        nextButton.closest('form').submit(); 
                    }, 500); 
                });
            }
        });
    </script>

    <?php include 'footer.php'; ?>
</body>
</html>