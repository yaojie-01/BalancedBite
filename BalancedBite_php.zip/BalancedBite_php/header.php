<?php 

if (session_status() === PHP_SESSION_NONE) {
    session_start(); 
}

$is_logged_in = isset($_SESSION['user_id']);
?>

<link rel="stylesheet" type="text/css" href="style_header.css">
    <div class="top_bar">
        <div class="logo">
            <a href="index.php">
                <img src="BALANCE_BITE.webp" alt="logo">
                <span class="website_name">BalancedBite</span>
            </a>
            <div class="for_hidden_menu">
                <a href="index.php" class="Home">Home</a>
                <a href="about_us.php" class="about_us">About Us</a>
            </div>
        </div>
        <div class="right_button">
            <a href="quiz.php" class="start-quiz">Start quiz</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="users_button">
                    <a href="profile.php" class="profile_button">Profile</a>
                    <a href="logout.php" class="logout_button">Logout</a>
                </div>
            <?php else: ?>
                <a href="login.php" class="sgn_button">Sign In/Up</a>
            <?php endif; ?>
        </div>

        <nav class="hamburger-menu">
            <div id="menu_icon" class="menu-icon">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <ul id="menu_item" class="menu-item">
                <li><a href="index.php">Home</a></li>
                <li><a href="about_us.php">About Us</a></li>
            </ul>
        </nav>
    </div>

   
    <script>
        const menu_icon = document.getElementById("menu_icon")
        const menu_item = document.getElementById("menu_item")


        menu_icon.addEventListener("click", () => {
            menu_icon.classList.toggle("open")
            menu_item.classList.toggle("open");
        })

    </script>