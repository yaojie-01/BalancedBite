<?php
session_start();
include 'db_connection.php';
include 'header.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$user_sql = "SELECT username, email FROM users WHERE id = ?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style_profile.css">
    <link rel="icon" href="BALANCE_BITE.webp" type="image/x-icon">
    <title>Profile</title>
</head>
<body>
    <h2>Your Profile</h2>

    <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>

    <a href= "edit_profile.php">
    <button>Edit Profile</button>
    </a>

    <h2>Your Quiz History</h2>

    <?php
    $sql = "SELECT qr.quiz_id, 
                GROUP_CONCAT(CONCAT(qr.deficiency, ' - Severity: ', qr.severity, ' | Recommended: ', d.recommended_food) SEPARATOR '<br>') AS deficiencies
            FROM quiz_results qr
            JOIN deficiencies d ON qr.deficiency = d.deficiency_name
            WHERE qr.user_id = ?
            GROUP BY qr.quiz_id
            ORDER BY qr.quiz_id DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    ?>

    <?php if ($result->num_rows > 0): ?>
        <table border="1">
            <tr>
                <th>Quiz ID</th>
                <th>Results</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['quiz_id']; ?></td>
                    <td><?php echo $row['deficiencies']; ?></td>
                    <td>
                        <form action="delete_quiz.php" method="POST">
                            <input type="hidden" name="quiz_id" value="<?php echo $row['quiz_id']; ?>">
                            <button type="submit" onclick="return confirm('Are you sure you want to delete this quiz?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No past quiz results found.</p>
    <?php endif; ?>

    <?php include 'footer.php'; ?>

</body>
</html>
