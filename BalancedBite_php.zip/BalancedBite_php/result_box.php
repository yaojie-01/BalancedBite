<link rel="stylesheet" type="text/css" href="style_result.css">
<div class="box-arrange">
    <div class="box">
        <h1>Your Nutrition Analysis</h1>
        <?php  
        if (!empty($deficiencies)) {
            echo "<h3>Quiz ID: " . htmlspecialchars($latest_quiz_id) . "</h3>";
            echo "<div class='deficiency-list'>";
            foreach ($deficiencies as $deficiency) {
                echo "<p><strong>" . htmlspecialchars($deficiency['deficiency']) . "</strong> - Severity: <span class='severity'>" . htmlspecialchars($deficiency['severity']) . "</span></p>";
            }
            echo "</div>";
        } else {
            echo "<p>No results found.</p>";
        }
        ?>
        <a href="index.php" class="back-button">Back to Main Page</a>
    </div>
</div>