<?php
session_start();
require 'db_connection.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "Please fill in all fields.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Username or email already taken.";
        } else {
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $password);
            
            if ($stmt->execute()) {
                $_SESSION['user_id'] = $stmt->insert_id;
                $_SESSION['username'] = $username;
                
                header("Location: index.php");
                exit();
            } else {
                $error = "Something went wrong. Try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign up</title>
    <link rel="icon" href="BALANCE_BITE.webp" type="image/x-icon">
    <link rel="stylesheet" href="style_in_up.css">
</head>
<body>
    <div class="overlay">
        <video autoplay loop muted playsinline class="overlay-video">
        <source src="food.mp4" type="video/mp4">
        </video>
        <div class="sign_up_box">
            <h2>Sign Up</h2>
        
            <?php if (isset($error)): ?>
                <p style="color: red;"><?php echo $error; ?></p>
            <?php endif; ?>
        
            <form action="register.php" method="POST">
                <label for="username" class="username_label">Username</label>
                <input type="text" name="username" required placeholder="Enter your username">
        
                <label for="email" class="email_label">Email</label>
                <input type="email" name="email" required placeholder="Enter your email">
        
                <label for="password" class="password_label">Password</label>
                <input type="password" name="password" required placeholder="Enter your password">
        
                <label for="confirm_password" class="confirm_password_label">Confirm Password</label>
                <input type="password" name="confirm_password" required placeholder="Confirm your password">

                <a href="login.php" class="change_btn">Already have an account? Login</a>
                
                <div class="all_register_btn">
                    <a href="index.php" class="back_btn">Back</a>
                    <button type="submit" class="sign_up_btn">Sign Up</button>
                </div>
            </form>
        

        </div>
    </div>

</body>
</html>
