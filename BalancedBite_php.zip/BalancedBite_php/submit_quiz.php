<?php
session_start();
require 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    die("Error: User not logged in.");
}


$answers = [];
if (isset($_POST['answers'])) {
    $answers = $_POST['answers'];
} elseif (isset($_SESSION['answers'])) {
    $answers = $_SESSION['answers'];
}

$user_id = $_SESSION['user_id'];

$query = "SELECT MAX(quiz_id) AS last_quiz_id FROM quiz_results WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$quiz_id = $row['last_quiz_id'] ? $row['last_quiz_id'] + 1 : 1; 

foreach ($answers as $question_id => $selected_option) {
    saveQuizResult($conn, $user_id, $quiz_id, $question_id, $selected_option);
}

if (isset($_SESSION['answers'])) {
    unset($_SESSION['answers']);
    unset($_SESSION['current_question']);
    unset($_SESSION['quiz_started']);
}

header("Location: results.php");
exit();

function saveQuizResult($conn, $user_id, $quiz_id, $question_id, $selected_option) {
    $query = "SELECT d.deficiency_name, d.mild_threshold, d.moderate_threshold, d.severe_threshold 
              FROM questions q 
              JOIN deficiencies d ON q.deficiency_id = d.id 
              WHERE q.id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $question_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row) {
        $deficiency_name = $row['deficiency_name'];
        $mild_threshold = $row['mild_threshold'];
        $moderate_threshold = $row['moderate_threshold'];
        $severe_threshold = $row['severe_threshold'];

        if ($selected_option >= 4) {
            $severity = "No Deficiency";
        } elseif ($selected_option >= 2) {
            $severity = "Moderate";
        } elseif ($selected_option >= 1) {
            $severity = "Mild";
        } else {
            $severity = "Severe";
        }

        $query = "INSERT INTO quiz_results (quiz_id, user_id, question_id, selected_option, deficiency, severity) 
                  VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iiisss", $quiz_id, $user_id, $question_id, $selected_option, $deficiency_name, $severity);
        $stmt->execute();
    }
}
