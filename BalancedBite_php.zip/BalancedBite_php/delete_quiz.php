<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['quiz_id'])) {
    $quiz_id = $_POST['quiz_id'];
    $user_id = $_SESSION['user_id'];

    $sql = "DELETE FROM quiz_results WHERE quiz_id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $quiz_id, $user_id);

    if ($stmt->execute()) {
        $sql_update = "UPDATE quiz_results SET quiz_id = quiz_id - 1 WHERE quiz_id > ? AND user_id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("ii", $quiz_id, $user_id);
        $stmt_update->execute();

        header("Location: profile.php");
        exit();
    } else {
        echo "Error deleting quiz.";
    }
}
?>
