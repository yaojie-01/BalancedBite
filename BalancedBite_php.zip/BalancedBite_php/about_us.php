<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="icon" href="BALANCE_BITE.webp" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="<?php echo 'style_about_us.css'; ?>">
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="Reasons">
        <h1>Discover Your Path to a Healthier You!</h1>
        <h2>Our website takes the guesswork out of eating well by analyzing your eating habits and providing personalized recommendations for a well-rounded diet. Whether you're trying to have more energy, lose weight, or just feel good about what you're eating, we're here to make it easy. Let's take the stress out of eating well—one step at a time!</h2>
        <a href="quiz.php" class="start-assessment">Start assessment</a>
    </div>

    <div class="box-arrange">
        <div class="box">
            <h2>Personalized Analysis</h2>
            <p>Answer simple questions about your meals, and we'll analyze your responses to uncover patterns in your diet.</p>
        </div>
        <div class="box">
            <h2>Get Balanced Diet Tips</h2>
            <p>Receive practical, easy-to-follow tips to improve your meals and align them with a balanced diet. No complicated rules—just straightforward advice.</p>
        </div>
        <div class="box">
            <h2>Achieve Your Health Goals</h2>
            <p>Whether you want to boost energy, maintain a healthy weight, or improve overall nutrition, we'll provide recommendations to help you stay on track.</p>
        </div>
        <div class="box">
            <h2>Easy and Accessible</h2>
            <p>No need to guess—our user-friendly platform is designed to make healthy eating simple, clear, and stress-free, wherever you are.</p>
        </div>
    </div>

    <div class="pictures-combination">
        <div class="pictures-info">
            <div class="text-container">
                <h2>Why Should You Try This?</h2>
                <ul>
                    <li>Take Control of Your Health: Understanding your eating habits is the first step to building a healthier lifestyle. By analyzing your meals, you'll gain valuable insights into your nutrition.</li>
                    <li>Small Changes, Big Impact: A balanced diet doesn't mean a complete overhaul. Even small adjustments can make a huge difference in how you feel, look, and live.</li>
                </ul>
            </div>
            <img src="healthy_lifestyle.png" alt="Healthy Lifestyle picture">
        </div>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>