<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BalancedBite</title>
    <link rel="icon" href="BALANCE_BITE.webp" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="<?php echo 'style_main_page.css'; ?>">
</head>
<body>
    <?php include "header.php"; ?>
    <div class="Quotes">
            <h1>Discover your nutritional needs</h1>
            <h2>“The greatest wealth is health”</h2>
            <a href="quiz.php" class="start-assessment">Start assessment</a>
        </div>
    
        <div class="box-arrange">
            <div class="box">
                <h2>Eat a Rainbow</h2>
                <p>Choose colorful fruits and vegetables to ensure you're getting a variety of vitamins, minerals, and antioxidants. Each color offers unique health benefits.</p>
            </div>
            <div class="box">
                <h2>Don't Skip Breakfast</h2>
                <p>Start your day with a nutrient-rich meal to kickstart your metabolism and provide energy. Include protein, healthy fats, and complex carbohydrates.</p>
            </div>
            <div class="box">
                <h2>Healthy Snacking</h2>
                <p>Choose snacks like fruits, nuts, yogurt, or whole-grain crackers instead of chips or sugary treats to stay energized between meals.</p>
            </div>
            <div class="box">
                <h2>Plan Your Meals</h2>
                <p>Plan and prep your meals in advance to avoid relying on fast food or processed options. Meal planning saves time and ensures balanced choices.</p>
            </div>
        </div>
    
        <div class="pictures-combination">
            <div class="pictures-info">
                <div class="text-container">
                    <h2>A Visual Guide To Balance Diet</h2>
                    <p>This vibrant meal is a perfect representation of a balanced diet. It includes nutrient-rich components like fresh greens, creamy avocado, soft-boiled eggs, vibrant radishes, and juicy cherry tomatoes. The addition of zucchini noodles, sprinkled seeds, and a touch of seasoning enhances both flavor and nutrition. Pairing these elements with a light beverage, as seen here, ensures a wholesome, well-rounded meal. Each ingredient is thoughtfully chosen to support a variety of dietary needs, making it an ideal inspiration for anyone seeking a healthy lifestyle. 🍎🥦🍞🍗🥑</p>
                </div>
                <img src="food_combination_picture.png" alt="Food combination picture">
            </div>
        </div>
    <?php include 'footer.php'; ?>
</body>
</html>